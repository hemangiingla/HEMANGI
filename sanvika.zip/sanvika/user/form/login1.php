<?php
$Name = $_POST['name'];
$Password = $_POST['password'];

$con = mysqli_connect('localhost', 'root', '', 'ecomerce');
$result = mysqli_query($con,"SELECT * FROM `tbluser` WHERE (UserName = '$Name' OR Email = '$Name') AND Password = '$Password'") ;

session_start();
if(mysqli_num_rows($result)){

    $_SESSION['user'] = $Name;
    echo"
    <script>
    alert('Login Successful');
    window.location.href='../index.php';
    </script>
    ";
}
else{
    echo"
    <script>
    alert('Invalid Login');
    window.location.href='login.php';
    </script>
    ";
}

?>