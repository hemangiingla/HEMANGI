<?php
$con = mysqli_connect('localhost', 'root', '', 'ecomerce');

$A_name = $_POST['username'];
$A_password = $_POST['userpassword'];

// Sanitize input to prevent SQL injection
$A_name = mysqli_real_escape_string($con, $A_name);
$A_password = mysqli_real_escape_string($con, $A_password);

$result = mysqli_query($con, "SELECT * FROM `admin` WHERE username='$A_name' AND userpassword='$A_password'");

session_start();
if(mysqli_num_rows($result)) {

    $_SESSION['admin'] = $A_name;

    echo "
        <script>
            alert('Login successful');
            window.location.href='../mystore.php';
        </script>
    ";
} else {
    echo "
        <script>
            alert('Invalid username/password');
            window.location.href='login.php';
        </script>
    ";
}
?>
